/* Consider a scenario where a new order is placed on the Olist website.
Using insertion statements, show the insertion of data regarding a particular order and show in what order and 
how each table is modified*/


--order dataset
insert into order_dataset 
(order_id,order_status,order_purchase_timestamp,order_approved_at,
order_delivered_carrier_date,order_delivered_customer_date,order_estimated_delivery_date) 
values 
('abc123456','processing', '2017-12-17', '2017-12-17',
null, null, '2017-12-26');

select * from order_dataset where order_id = 'abc123456';

--customer dataset
insert into customer_dataset 
(cust_order_id,cust_unique_id,cust_zip,cust_city,cust_state) 
values 
('abc123456','cust123',98700,'ijui','RJ');

select * from customer_dataset where cust_order_id = 'abc123456';

--Seller_dataset
insert into seller_dataset 
(seller_id,seller_zip_code,seller_city,seller_state) 
values
('sell1234',4164,'sao paulo','SP');

select * from seller_dataset where seller_id = 'sell1234';

--Product_dataset
insert into product_dataset 
(product_id,product_category,product_weight_g,product_length_cm) 
values 
('prod1234', 'jewellery', 50, 4);

select * from product_dataset where product_id = 'prod1234';

--order_review
insert into order_reviews 
(review_id,order_id,review_score,review_comment) 
values 
('view1234', 'abc123456', 1, 'My order is still not delivered');

select * from order_reviews where order_id = 'abc123456';

--or NO REVIEW HAS BEEN SUBMITTED YET BY THE CUSTOMER IS ALSO A POSSIBLE ACTION
delete from order_reviews where review_id = 'view1234';
select * from order_reviews where order_id = 'abc123456';

--payment_dataset
delete from payment_dataset where order_id = 'abc123456';
insert into payment_dataset
(order_id, payment_id,payment_type, payment_installments, payment_values) 
values 
('abc123456', 'DM76D','credit_card', 2, 50.65);

insert into payment_dataset
(order_id, payment_id,payment_type, payment_installments, payment_values) 
values 
('abc123456', 'DM76G','credit_card', 2, 50.65);


Select * from payment_dataset where payment_id = 'DM76D';
Select * from payment_dataset where order_id = 'abc123456';

--order_items_dataset
insert into order_items 
(order_id,order_item_id,product_id,seller_id,shipping_date,price) 
values 
('abc123456', 1, 'prod1234', 'sell1234', null ,50.65);

select * from order_items where order_id='abc123456';


/*The above set of statements help realise the order in which the insert statements 
are to be executed in order to enter details into the respective tables without 
having any discrepencies*/