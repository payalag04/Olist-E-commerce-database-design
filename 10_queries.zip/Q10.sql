/*How many customers belong to a particular area based on the data collected from the customers, such as state*/


Select cust_state, count(cust_unique_id) customer_count 
from customer_dataset
group by cust_state
order by customer_count DESC; 



/*Explaination : This particular query uses count function to return state wise 
count of the number of customers who placed orders from that particular state*/