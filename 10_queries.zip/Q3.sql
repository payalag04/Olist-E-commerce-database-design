
/* Will the database be able to display the product category that was sold the most or least 
having a particularly specified review score? Write a query that displays the item that was 
most sold and has a high rating (review_score=5)*/


with cat_count as
(select p.product_category, count(p.product_id) count_Reviews from order_reviews r, 
order_items s, product_dataset p
where r.order_id = s.order_id and r.review_score = 5 and p.product_id = s.product_id 
group by p.product_category
order by count_Reviews desc),
max_val as (
select max(count_Reviews) as count_val from cat_count c)
select c.product_category, c.count_Reviews from cat_count c, max_val m where 
c.count_Reviews = m.count_val;

/* Using the idea of sub queries and aggregate functions in mysql we are trying to find the product_category that 
was given the highest number of review_score = 5*/
