/* Q1) Will the customer be able to view reviews of all the products that are sold by a particular seller in the listed states? 
In this case what query helps recommend the product on review score basis?  */


select s.seller_id, p.product_id, ors.review_score
from seller_dataset s, product_dataset p, order_items oi, order_reviews ors
where s.seller_id = '0015a82c2db000af6aaaf3ae2ecb0532'
and p.product_id = oi.product_id
and oi.order_id = ors.order_id
order by review_score;


/* Explanation - This query helps customer view all the products with all the reviews those products received of a praticular seller. */











