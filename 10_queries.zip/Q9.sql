/* Using triggers handle the occurrence of an event of ethics and privacy concerns where any card 
detail stored is then displayed on screen using special character * . */


ALTER TABLE payment_dataset
ADD card_num varchar(50);

CREATE TRIGGER card_num BEFORE INSERT ON payment_dataset
       FOR EACH ROW SET NEW.card_num = CONCAT(SUBSTRING(new.card_num,1,4), '****', SUBSTRING(new.card_num,13,4));


insert into payment_dataset(order_id, payment_id,payment_type, payment_installments, payment_values,card_num) 
values ('5f79b5b0931d63f1a42989eb65b9da6e', 'UW91M','credit_card', 8, 99.33, '4505675435241234');

select * from payment_dataset where payment_id = 'UW91M';


/*When a customer makes a payment, the database should not be storing any 
important information that may lead to misuse of the customer’s assets and/or 
lead to data breach. In the case where a customer decides to save his or her card 
details on the website for further purchases, then it should be made sure that 
other that the customer, no other individual including the DB Admin has access 
to the card information. This has been handled by creating a trigger – before 
insert, which makes sure that if the card details of a particular customer are being 
saved, then on the database side, the person will be able to see it as a 
combination of numbers and special symbols such as *. */