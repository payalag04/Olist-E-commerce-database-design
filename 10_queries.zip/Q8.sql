/* Q8) Searching for most used mode of payment OR displaying count of each payment mode used.  */


SELECT payment_type, COUNT(payment_type)
FROM payment_dataset
GROUP BY payment_type ;



/* Explanation - Here, we used the COUNT function to get the total occurrences of the type of payment used . 
From the results it can be determined that credit_card was the maximum use payment type. */