/* Q6) Displaying the count of items sold in each state. */


select c.cust_state, count(c.cust_order_id) sales_count
from customer_dataset c
group by c.cust_state
order by sales_count DESC;


/* Explanation -  This query helps us understand the sales done in each state in our given time range. The output of this query can help seller see which state has most sales and which has least and expand/decrease their sales from those states accordingly  */