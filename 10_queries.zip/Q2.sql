/* Q2) Will the Db Admin be able to display the order id and respective details where the sellers were not able to deliver the requested orders on or before time to the customers?  */


Select DISTINCT o.order_id, c.cust_unique_id, oi.order_item_id,oi.seller_id, r.review_score
from order_dataset o, order_items oi, customer_dataset c, order_reviews r
where o.order_id= oi.order_id and o.order_id = c.cust_order_id
and
oi.order_id = r.order_id
and
o.order_delivered_customer_date > o.order_estimated_delivery_date;



/* Explanation - With this query we can get stats of all the orders fulfilled by sellers where the delivery expectations were not met.
 We can check if a seller consistently is unable to deliver his orders on time or not.  */ 