/* Q7) Searching for product category name, product id and seller id with review score less than 2.  */


Select DISTINCT p.product_category, p.product_id, s.seller_id, r.review_score,r.review_comment
from product_dataset p, seller_dataset s, order_reviews r, order_items oi
where r.order_id= oi.order_id
and
oi.product_id = p.product_id
and
oi.order_id = r.order_id
and
oi.seller_id=s.seller_id and
r.review_score < 2;

/* Explanation - This query helps the customer view all the proucts which received a review score of less than 2. 
This is relevant in the scenario where one might need to see the least quality products on the website.  */ 
