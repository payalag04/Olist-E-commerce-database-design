/* Creation of view where u can find if a seller is also a customer*/

--order dataset
insert into order_dataset 
(order_id,order_status,order_purchase_timestamp,order_approved_at,
order_delivered_carrier_date,order_delivered_customer_date,order_estimated_delivery_date) 
values 
('abc1234567','delivered', '2017-12-15', '2017-12-15',
'2017-12-24', '2017-12-26', '2017-12-28');

--customer dataset
insert into customer_dataset 
(cust_order_id,cust_unique_id,cust_zip,cust_city,cust_state) 
values 
('abc1234567','cust1234',98700,'ijui','RJ');

select * from customer_dataset where cust_order_id = 'abc123456';

--Seller_dataset
insert into seller_dataset 
(seller_id,seller_zip_code,seller_city,seller_state) 
values
('cust123',98700,'ijui','RJ');

select * from seller_dataset where seller_id = 'cust123';

--Product_dataset
insert into product_dataset 
(product_id,product_category,product_weight_g,product_length_cm) 
values 
('prod12345', 'jewellery', 49, 3);

select * from product_dataset where product_id = 'prod12345';

--order_review
insert into order_reviews 
(review_id,order_id,review_score,review_comment) 
values 
('view1234', 'abc1234567', 4, 'Amazing!!!');

--payment_dataset
delete from payment_dataset where order_id = 'abc1234567';
insert into payment_dataset
(order_id, payment_id,payment_type, payment_installments, payment_values) 
values 
('abc1234567', 'DM66Y','credit_card', 2, 56);

--order_items_dataset
insert into order_items 
(order_id,order_item_id,product_id,seller_id,shipping_date,price) 
values 
('abc1234567', 1, 'prod12345', 'cust123', '2017-12-24' ,56);

CREATE VIEW seller_cust_view AS 
SELECT c.cust_unique_id, s.seller_id,oi.order_id from customer_dataset c, seller_dataset s, order_items oi
where oi.seller_id =s.seller_id and s.seller_id = c.cust_unique_id ;

Select * from seller_cust_view;




/*The above set of statements help realise the scenario where a seller may also be a valued customer on the Olist website.
It is a possibility that when a particular seller is in need of raw materials and wants to buy it off olist, he / she will
act a customer in this case. The above view helps create a non physically available table just to check if there are any 
such individuals who pose as a customer as well as a seller*/
